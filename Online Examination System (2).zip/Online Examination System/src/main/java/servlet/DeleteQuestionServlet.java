package com.onlineexam.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onlineexam.dao.QuestionDAO;

@WebServlet("/delete-question")
public class DeleteQuestionServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(
                request.getParameter("id")
        );

        QuestionDAO questionDAO =
                new QuestionDAO();

        boolean success =
                questionDAO.deleteQuestion(id);

        if (success) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/view-questions"
            );

        } else {

            response.setContentType(
                    "text/html;charset=UTF-8"
            );

            response.getWriter().println(
                    "<h2>Failed to delete question!</h2>" +
                    "<a href='view-questions'>Go Back</a>"
            );
        }
    }
}