
package com.onlineexam.servlet;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineexam.dao.ExamDAO;
import com.onlineexam.dao.QuestionDAO;
import com.onlineexam.dao.ResultDAO;
import com.onlineexam.model.Exam;
import com.onlineexam.model.Question;

@WebServlet("/start-exam")
public class StartExamServlet extends HttpServlet {

    private final ExamDAO examDAO = new ExamDAO();
    private final QuestionDAO questionDAO = new QuestionDAO();
    private final ResultDAO resultDAO = new ResultDAO();

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // 1. Check student login
        if (session == null
                || !"STUDENT".equals(session.getAttribute("role"))
                || session.getAttribute("userId") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login.html");
            return;
        }

        int userId;

        try {
            userId = Integer.parseInt(
                    String.valueOf(session.getAttribute("userId")));
        } catch (NumberFormatException e) {
            response.sendError(
                    HttpServletResponse.SC_UNAUTHORIZED,
                    "Invalid student session.");
            return;
        }

        // 2. Validate exam ID
        int examId;

        try {
            examId = Integer.parseInt(request.getParameter("id"));

            if (examId <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "Invalid exam ID.");
            return;
        }

        // 3. Load exam
        Exam exam = examDAO.getExamById(examId);

        if (exam == null) {
            response.sendError(
                    HttpServletResponse.SC_NOT_FOUND,
                    "Exam not found.");
            return;
        }

        // 4. Validate schedule
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime startTime = exam.getStartTime();
        LocalDateTime endTime = exam.getEndTime();

        if (startTime == null || endTime == null
                || !endTime.isAfter(startTime)) {

            showMessage(response, request,
                    "Exam Not Scheduled",
                    "This exam does not have a valid schedule.");
            return;
        }

        if (now.isBefore(startTime)) {
            showMessage(response, request,
                    "Exam Not Started Yet",
                    "This exam opens at " +
                    startTime.toString().replace('T', ' ') + ".");
            return;
        }

        if (!now.isBefore(endTime)) {
            showMessage(response, request,
                    "Exam Deadline Passed",
                    "The scheduled closing time has passed.");
            return;
        }

        // 5. Prevent retakes
        try {
            if (resultDAO.hasAttemptedExam(userId, examId)) {
                showMessage(response, request,
                        "Exam Already Attempted",
                        "You have already submitted this exam.");
                return;
            }
        } catch (RuntimeException e) {
            log("Unable to check previous exam attempt.", e);
            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unable to verify your previous exam attempt.");
            return;
        }

        // 6. Load questions before starting the timer
        List<Question> questions =
                questionDAO.getQuestionsByExamId(examId);

        if (questions == null || questions.isEmpty()) {
            showMessage(response, request,
                    "No Questions Available",
                    "Please ask the administrator to add questions.");
            return;
        }

        if (exam.getDuration() <= 0) {
            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "The exam duration is invalid.");
            return;
        }

        // 7. Store the first start time in the student's session.
        // Refreshing the page will reuse the original timestamp.
        String timerKey = "examStart_" + userId + "_" + examId;

        Object storedValue = session.getAttribute(timerKey);
        Long examStartMillis = null;

        if (storedValue instanceof Long) {
            examStartMillis = (Long) storedValue;
        }

        if (examStartMillis == null) {
            examStartMillis = System.currentTimeMillis();
            session.setAttribute(timerKey, examStartMillis);
        }

        // 8. Calculate remaining duration
        long elapsedSeconds = Math.max(
                0,
                (System.currentTimeMillis() - examStartMillis) / 1000
        );

        long durationSeconds = (long) exam.getDuration() * 60;

        long remainingSeconds = Math.max(
                0, durationSeconds - elapsedSeconds
        );

        // Also limit the timer to the scheduled closing time.
        long secondsUntilDeadline =
                Duration.between(
                        LocalDateTime.now(),
                        endTime
                ).getSeconds();

        remainingSeconds = Math.min(
                remainingSeconds,
                Math.max(0, secondsUntilDeadline)
        );

        if (remainingSeconds <= 0) {
            showMessage(response, request,
                    "Exam Time Expired",
                    "Your exam time has expired. Submission is no longer available.");
            return;
        }

        // 9. Forward exam data and remaining time to JSP
        request.setAttribute("exam", exam);
        request.setAttribute("questions", questions);
        request.setAttribute("remainingSeconds", remainingSeconds);

        request.getRequestDispatcher("/take-exam.jsp")
               .forward(request, response);
    }

    private void showMessage(HttpServletResponse response,
                             HttpServletRequest request,
                             String heading,
                             String message)
            throws IOException {

        response.setContentType("text/html;charset=UTF-8");

        response.getWriter().println(
            "<!DOCTYPE html><html lang='en'><head>" +
            "<meta charset='UTF-8'>" +
            "<meta name='viewport' content='width=device-width, initial-scale=1'>" +
            "<title>" + escapeHtml(heading) + "</title>" +
            "<style>" +
            "body{font-family:Arial,sans-serif;background:#f4f6f8;" +
            "text-align:center;padding:60px 15px;color:#333}" +
            ".card{background:white;max-width:550px;margin:auto;padding:30px;" +
            "border-radius:12px;box-shadow:0 5px 20px #0001}" +
            "a{display:inline-block;margin-top:20px;padding:12px 20px;" +
            "background:#667eea;color:white;text-decoration:none;border-radius:6px}" +
            "</style></head><body><div class='card'>" +
            "<h1>" + escapeHtml(heading) + "</h1>" +
            "<p>" + escapeHtml(message) + "</p>" +
            "<a href='" + request.getContextPath() +
            "/view-student-exams'>Back to Available Exams</a>" +
            "</div></body></html>");
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
