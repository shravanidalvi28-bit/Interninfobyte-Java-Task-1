
package com.onlineexam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineexam.util.DBConnection;

@WebServlet("/admin-stats")
public class AdminStatsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        // Only logged-in administrators can view statistics.
        if (session == null ||
                !"ADMIN".equals(session.getAttribute("role"))) {
            response.sendError(
                    HttpServletResponse.SC_FORBIDDEN,
                    "Admin access required.");
            return;
        }

        int totalStudents = 0;
        int totalExams = 0;
        int totalSubmissions = 0;
        double averagePercentage = 0.0;

        String studentsSql =
                "SELECT COUNT(*) FROM users WHERE role = 'STUDENT'";

        String examsSql =
                "SELECT COUNT(*) FROM exams";

        String submissionsSql =
                "SELECT COUNT(*) FROM results";

        String averageSql =
                "SELECT COALESCE(AVG(score * 100.0 / NULLIF(total_marks, 0)), 0) " +
                "FROM results";

        try (Connection connection = DBConnection.getConnection()) {

            try (PreparedStatement ps =
                         connection.prepareStatement(studentsSql);
                 ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    totalStudents = rs.getInt(1);
                }
            }

            try (PreparedStatement ps =
                         connection.prepareStatement(examsSql);
                 ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    totalExams = rs.getInt(1);
                }
            }

            try (PreparedStatement ps =
                         connection.prepareStatement(submissionsSql);
                 ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    totalSubmissions = rs.getInt(1);
                }
            }

            try (PreparedStatement ps =
                         connection.prepareStatement(averageSql);
                 ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    averagePercentage = rs.getDouble(1);
                }
            }

        } catch (SQLException e) {
            log("Unable to load admin statistics.", e);
            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unable to load dashboard statistics.");
            return;
        }

        response.setContentType("application/json;charset=UTF-8");

        PrintWriter out = response.getWriter();

        out.println("{");
        out.println("\"totalStudents\":" + totalStudents + ",");
        out.println("\"totalExams\":" + totalExams + ",");
        out.println("\"totalSubmissions\":" + totalSubmissions + ",");
        out.println("\"averageScore\":" +
                String.format(java.util.Locale.US, "%.2f", averagePercentage));
        out.println("}");
    }
}
