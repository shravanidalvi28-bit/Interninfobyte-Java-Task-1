
package com.onlineexam.servlet;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineexam.dao.ExamDAO;
import com.onlineexam.dao.QuestionDAO;
import com.onlineexam.dao.ResultDAO;
import com.onlineexam.model.Exam;
import com.onlineexam.model.Question;

@WebServlet("/submit-exam")
public class SubmitExamServlet extends HttpServlet {

    private static final long SUBMISSION_GRACE_MILLIS = 10_000L;

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        // 1. Validate exam ID
        String examIdValue = request.getParameter("examId");

        if (examIdValue == null || examIdValue.trim().isEmpty()) {
            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "Exam ID is missing.");
            return;
        }

        int examId;

        try {
            examId = Integer.parseInt(examIdValue.trim());

            if (examId <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "Invalid Exam ID.");
            return;
        }

        // 2. Verify that a student is logged in
        HttpSession session = request.getSession(false);

        if (session == null
                || session.getAttribute("userId") == null
                || !"STUDENT".equalsIgnoreCase(
                        String.valueOf(session.getAttribute("role")))) {

            response.sendRedirect(
                    request.getContextPath() + "/login.html");
            return;
        }

        int studentId;

        try {
            studentId = Integer.parseInt(
                    String.valueOf(session.getAttribute("userId")));
        } catch (NumberFormatException e) {
            response.sendError(
                    HttpServletResponse.SC_UNAUTHORIZED,
                    "Invalid student session.");
            return;
        }

        ExamDAO examDAO = new ExamDAO();
        ResultDAO resultDAO = new ResultDAO();

        // 3. Verify that the exam exists
        Exam exam = examDAO.getExamById(examId);

        if (exam == null) {
            response.sendError(
                    HttpServletResponse.SC_NOT_FOUND,
                    "Exam not found.");
            return;
        }

        // 4. Validate the exam schedule
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime startTime = exam.getStartTime();
        LocalDateTime endTime = exam.getEndTime();

        if (startTime == null || endTime == null
                || !endTime.isAfter(startTime)) {

            showMessage(response, request,
                    "Exam Not Scheduled",
                    "This exam does not have a valid schedule.");
            return;
        }

        if (now.isBefore(startTime)) {
            showMessage(response, request,
                    "Exam Has Not Started",
                    "The scheduled start time has not arrived.");
            return;
        }

        if (!now.isBefore(endTime)) {
            showMessage(response, request,
                    "Exam Deadline Passed",
                    "The scheduled submission deadline has passed.");
            return;
        }

        // 5. Validate the server-side timer
        String timerKey = "examStart_" + studentId + "_" + examId;
        Object storedStart = session.getAttribute(timerKey);

        if (!(storedStart instanceof Long)) {
            showMessage(response, request,
                    "Exam Session Expired",
                    "Your exam start time could not be verified. "
                    + "Please contact the administrator.");
            return;
        }

        long startedAt = (Long) storedStart;
        long elapsedMillis = System.currentTimeMillis() - startedAt;
        long allowedMillis = (long) exam.getDuration() * 60_000L;

        if (exam.getDuration() <= 0 || elapsedMillis < 0) {
            showMessage(response, request,
                    "Invalid Exam Timer",
                    "The exam timer could not be validated.");
            return;
        }

        /*
         * A short grace period helps accommodate the browser's
         * automatic timeout submission request.
         *
         * This is not a fully secure way to establish when answers
         * were selected. The scheduled exam deadline is still enforced.
         */
        if (elapsedMillis > allowedMillis + SUBMISSION_GRACE_MILLIS) {
            showMessage(response, request,
                    "Exam Time Expired",
                    "The submission arrived after the permitted duration "
                    + "and grace period. Your answers were not saved.");
            return;
        }

        // 6. Prevent duplicate submissions
        try {
            if (resultDAO.hasAttemptedExam(studentId, examId)) {
                session.removeAttribute(timerKey);

                showMessage(response, request,
                        "Exam Already Submitted",
                        "You have already submitted this exam.");
                return;
            }
        } catch (RuntimeException e) {
            log("Could not verify the previous exam submission.", e);

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unable to verify your previous submission.");
            return;
        }

        // 7. Fetch the exam questions
        QuestionDAO questionDAO = new QuestionDAO();

        List<Question> questions =
                questionDAO.getQuestionsByExamId(examId);

        if (questions == null || questions.isEmpty()) {
            response.sendError(
                    HttpServletResponse.SC_BAD_REQUEST,
                    "No questions found for this exam.");
            return;
        }

        // 8. Calculate the score using the submitted answers
        int score = 0;
        int totalMarks = 0;

        for (Question question : questions) {
            totalMarks += question.getMarks();

            String selectedAnswer = request.getParameter(
                    "question_" + question.getId());

            if (selectedAnswer != null
                    && selectedAnswer.trim().equalsIgnoreCase(
                            question.getCorrectAnswer())) {

                score += question.getMarks();
            }
        }

        // 9. Save the result in MySQL
        boolean saved;

        try {
            saved = resultDAO.saveResult(
                    studentId, examId, score, totalMarks);
        } catch (RuntimeException e) {
            log("Unable to save exam result.", e);

            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unable to save your result. Please try again.");
            return;
        }

        if (!saved) {
            response.sendError(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unable to save your result. Please try again.");
            return;
        }

        // 10. Store result information in the session
        session.setAttribute("lastExamId", examId);
        session.setAttribute("lastExamScore", score);
        session.setAttribute("lastExamTotal", totalMarks);

        // Clear the timer after successful submission
        session.removeAttribute(timerKey);

        // 11. Forward to the result page
        request.setAttribute("examId", examId);
        request.setAttribute("score", score);
        request.setAttribute("totalMarks", totalMarks);

        request.getRequestDispatcher("/exam-result.jsp")
               .forward(request, response);
    }

    private void showMessage(
            HttpServletResponse response,
            HttpServletRequest request,
            String heading,
            String message) throws IOException {

        response.setContentType("text/html;charset=UTF-8");

        String contextPath = request.getContextPath();

        response.getWriter().println(
            "<!DOCTYPE html>"
            + "<html lang='en'>"
            + "<head>"
            + "<meta charset='UTF-8'>"
            + "<meta name='viewport' "
            + "content='width=device-width, initial-scale=1'>"
            + "<title>" + escapeHtml(heading) + "</title>"
            + "<style>"
            + "*{box-sizing:border-box}"
            + "body{font-family:Arial,sans-serif;"
            + "background:#f4f6f8;text-align:center;"
            + "padding:50px 15px;color:#333;margin:0}"
            + ".card{background:white;max-width:550px;"
            + "margin:auto;padding:30px;border-radius:12px;"
            + "box-shadow:0 5px 20px rgba(0,0,0,.08)}"
            + "a{display:inline-block;margin-top:20px;"
            + "padding:12px 20px;background:#667eea;"
            + "color:white;text-decoration:none;border-radius:6px}"
            + "a:hover{background:#5568d9}"
            + "</style>"
            + "</head>"
            + "<body>"
            + "<div class='card'>"
            + "<h1>" + escapeHtml(heading) + "</h1>"
            + "<p>" + escapeHtml(message) + "</p>"
            + "<a href='" + escapeHtml(contextPath)
            + "/view-student-exams'>"
            + "Back to Available Exams</a>"
            + "</div>"
            + "</body>"
            + "</html>");
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
