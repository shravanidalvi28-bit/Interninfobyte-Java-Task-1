
package com.onlineexam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineexam.util.DBConnection;

@WebServlet("/admin-users")
public class AdminUsersServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null ||
                !"ADMIN".equals(session.getAttribute("role"))) {
            response.sendRedirect(
                    request.getContextPath() + "/login.html");
            return;
        }

        response.setContentType("text/html;charset=UTF-8");

        String search = request.getParameter("search");

        if (search == null) {
            search = "";
        }

        String sql =
                "SELECT id, name, email, role FROM users " +
                "WHERE name LIKE ? OR email LIKE ? " +
                "ORDER BY id";

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html><html lang='en'><head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Manage Users</title>");

        out.println("<style>");
        out.println("*{box-sizing:border-box}");
        out.println("body{font-family:Arial,sans-serif;background:#f4f6f8;margin:0;color:#333}");
        out.println("header{background:#667eea;color:white;padding:25px;text-align:center}");
        out.println(".container{width:94%;max-width:1100px;margin:30px auto}");
        out.println(".back{display:inline-block;margin-bottom:20px;color:#667eea;text-decoration:none}");
        out.println(".panel{background:white;padding:24px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,.08);overflow-x:auto}");
        out.println(".search{display:flex;gap:10px;margin:20px 0}");
        out.println("input{padding:11px;border:1px solid #ccc;border-radius:6px;flex:1;min-width:0}");
        out.println("button{padding:11px 18px;background:#667eea;color:white;border:0;border-radius:6px;cursor:pointer}");
        out.println("table{width:100%;border-collapse:collapse;min-width:550px}");
        out.println("th,td{padding:13px;text-align:left;border-bottom:1px solid #eee}");
        out.println("th{background:#667eea;color:white}");
        out.println("tr:hover td{background:#f8f9ff}");
        out.println(".empty{text-align:center;padding:25px;color:#666}");
        out.println("@media(max-width:550px){.search{flex-direction:column}}");
        out.println("</style></head><body>");

        out.println("<header><h1>Manage Users</h1>");
        out.println("<p>Online Examination System - Admin Panel</p></header>");

        out.println("<main class='container'>");
        out.println("<a class='back' href='" +
                request.getContextPath() +
                "/admin.html'>← Back to Admin Dashboard</a>");

        out.println("<div class='panel'>");
        out.println("<h2>Registered Users</h2>");

        out.println("<form class='search' method='get' action='" +
                request.getContextPath() + "/admin-users'>");

        out.println("<input type='search' name='search' placeholder='Search by name or email' value='" +
                escapeHtml(search) + "'>");

        out.println("<button type='submit'>Search</button>");
        out.println("</form>");

        out.println("<table><thead><tr>");
        out.println("<th>ID</th><th>Name</th><th>Email</th><th>Role</th>");
        out.println("</tr></thead><tbody>");

        int count = 0;

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            String pattern = "%" + search + "%";
            ps.setString(1, pattern);
            ps.setString(2, pattern);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    count++;

                    out.println("<tr>");
                    out.println("<td>" + rs.getInt("id") + "</td>");
                    out.println("<td>" +
                            escapeHtml(rs.getString("name")) + "</td>");
                    out.println("<td>" +
                            escapeHtml(rs.getString("email")) + "</td>");
                    out.println("<td>" +
                            escapeHtml(rs.getString("role")) + "</td>");
                    out.println("</tr>");
                }
            }

        } catch (SQLException e) {
            log("Unable to load users.", e);
            response.setStatus(
                    HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.println("<tr><td colspan='4' class='empty'>Unable to load users. Check the server logs.</td></tr>");
            out.println("</tbody></table></div></main></body></html>");
            return;
        }

        if (count == 0) {
            out.println("<tr><td colspan='4' class='empty'>No matching users found.</td></tr>");
        }

        out.println("</tbody></table>");
        out.println("<p><strong>Users displayed: " + count + "</strong></p>");
        out.println("</div></main></body></html>");
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
