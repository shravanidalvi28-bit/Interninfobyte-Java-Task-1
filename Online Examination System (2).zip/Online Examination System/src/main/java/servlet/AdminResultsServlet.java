
package com.onlineexam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineexam.util.DBConnection;

@WebServlet("/admin-results")
public class AdminResultsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        // Allow only administrators
        HttpSession session = request.getSession(false);

        if (session == null ||
                !"ADMIN".equals(session.getAttribute("role"))) {
            response.sendRedirect(
                    request.getContextPath() + "/login.html");
            return;
        }

        response.setContentType("text/html;charset=UTF-8");

        String sql =
                "SELECT u.name AS student_name, u.email, " +
                "e.title AS exam_title, r.score, " +
                "r.total_marks, r.submitted_at " +
                "FROM results r " +
                "INNER JOIN users u ON r.user_id = u.id " +
                "INNER JOIN exams e ON r.exam_id = e.id " +
                "ORDER BY r.submitted_at DESC";

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Student Results</title>");

        out.println("<style>");
        out.println("* { box-sizing: border-box; }");
        out.println("body { font-family: Arial, sans-serif; background: #f4f6f8; margin: 0; color: #333; }");
        out.println("header { background: #667eea; color: white; text-align: center; padding: 25px; }");
        out.println(".container { width: 94%; max-width: 1200px; margin: 30px auto; }");
        out.println(".back { display: inline-block; color: #667eea; text-decoration: none; margin-bottom: 20px; }");
        out.println(".panel { background: white; padding: 22px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,.08); overflow-x: auto; }");
        out.println("table { width: 100%; border-collapse: collapse; min-width: 750px; }");
        out.println("th, td { padding: 14px; text-align: left; border-bottom: 1px solid #eee; }");
        out.println("th { background: #667eea; color: white; }");
        out.println("tr:hover td { background: #f8f9ff; }");
        out.println(".score { font-weight: bold; color: #16834a; }");
        out.println(".empty { text-align: center; padding: 30px; color: #666; }");
        out.println("</style>");

        out.println("</head><body>");

        out.println("<header>");
        out.println("<h1>Student Examination Results</h1>");
        out.println("<p>Online Examination System - Admin Panel</p>");
        out.println("</header>");

        out.println("<main class='container'>");
        out.println("<a class='back' href='" +
                request.getContextPath() +
                "/admin.html'>← Back to Admin Dashboard</a>");

        out.println("<div class='panel'>");
        out.println("<h2>All Submitted Results</h2>");

        out.println("<table>");
        out.println("<thead><tr>");
        out.println("<th>Student Name</th>");
        out.println("<th>Email</th>");
        out.println("<th>Exam</th>");
        out.println("<th>Score</th>");
        out.println("<th>Total Marks</th>");
        out.println("<th>Submitted At</th>");
        out.println("</tr></thead><tbody>");

        int count = 0;

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                count++;

                out.println("<tr>");

                out.println("<td>" +
                        escapeHtml(rs.getString("student_name")) +
                        "</td>");

                out.println("<td>" +
                        escapeHtml(rs.getString("email")) +
                        "</td>");

                out.println("<td>" +
                        escapeHtml(rs.getString("exam_title")) +
                        "</td>");

                out.println("<td class='score'>" +
                        rs.getInt("score") + "</td>");

                out.println("<td>" +
                        rs.getInt("total_marks") + "</td>");

                out.println("<td>" +
                        escapeHtml(rs.getString("submitted_at")) +
                        "</td>");

                out.println("</tr>");
            }

        } catch (SQLException e) {
            log("Unable to retrieve student results.", e);

            out.println("</tbody></table>");
            out.println("<p>Unable to load results. Please check the server logs.</p>");
            out.println("</div></main></body></html>");
            return;
        }

        if (count == 0) {
            out.println("<tr><td colspan='6' class='empty'>");
            out.println("No exam results have been submitted yet.");
            out.println("</td></tr>");
        }

        out.println("</tbody></table>");
        out.println("<p><strong>Total submissions: " +
                count + "</strong></p>");

        out.println("</div></main>");
        out.println("</body></html>");
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
