package com.onlineexam.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineexam.dao.UserDAO;
import com.onlineexam.model.User;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Get email and password from login form
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Create UserDAO object
        UserDAO userDAO = new UserDAO();

        // Check login credentials
        User user = userDAO.login(email, password);

        if (user != null) {

            // Create session
            HttpSession session = request.getSession();

            session.setAttribute("user", user);
            session.setAttribute("userId", user.getId());
            session.setAttribute("userName", user.getName());
            session.setAttribute("role", user.getRole());

            // Check user role
            if ("ADMIN".equalsIgnoreCase(user.getRole())) {

                response.sendRedirect(
                        request.getContextPath() + "/admin.html"
                );

            } else if ("STUDENT".equalsIgnoreCase(user.getRole())) {

                response.sendRedirect(
                        request.getContextPath() + "/student.html"
                );

            } else {

                response.setContentType("text/html");

                response.getWriter().println(
                        "<h2>Invalid user role!</h2>"
                );
            }

        } else {

            // Invalid login
            response.setContentType("text/html");

            response.getWriter().println(
                    "<html>" +
                    "<head><title>Login Failed</title></head>" +
                    "<body>" +
                    "<h2>Invalid email or password!</h2>" +
                    "<a href='login.html'>Try Again</a>" +
                    "</body>" +
                    "</html>"
            );
        }
    }
}