
package com.onlineexam.servlet;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineexam.dao.ExamDAO;
import com.onlineexam.model.Exam;

@WebServlet("/add-exam")
public class AddExamServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Allow only admin users
        HttpSession session = request.getSession(false);

        if (session == null ||
                !"ADMIN".equals(session.getAttribute("role"))) {

            response.sendRedirect(
                    request.getContextPath() + "/login.html");
            return;
        }

        request.setCharacterEncoding("UTF-8");

        try {
            String title = request.getParameter("title");
            String subject = request.getParameter("subject");

            String durationValue = request.getParameter("duration");
            String marksValue = request.getParameter("totalMarks");
            String startValue = request.getParameter("startTime");
            String endValue = request.getParameter("endTime");

            // Validate required fields
            if (isBlank(title) || isBlank(subject) ||
                    isBlank(durationValue) || isBlank(marksValue) ||
                    isBlank(startValue) || isBlank(endValue)) {

                showError(response, request,
                        "Please fill in all fields.");
                return;
            }

            int duration = Integer.parseInt(durationValue);
            int totalMarks = Integer.parseInt(marksValue);

            if (duration <= 0 || totalMarks <= 0) {
                showError(response, request,
                        "Duration and total marks must be greater than zero.");
                return;
            }

            // Convert datetime-local values to LocalDateTime
            LocalDateTime startTime =
                    LocalDateTime.parse(startValue);

            LocalDateTime endTime =
                    LocalDateTime.parse(endValue);

            if (!endTime.isAfter(startTime)) {
                showError(response, request,
                        "Exam end time must be later than start time.");
                return;
            }

            // Create exam
            Exam exam = new Exam();
            exam.setTitle(title.trim());
            exam.setSubject(subject.trim());
            exam.setDuration(duration);
            exam.setTotalMarks(totalMarks);
            exam.setStartTime(startTime);
            exam.setEndTime(endTime);

            // Save exam to database
            ExamDAO examDAO = new ExamDAO();
            boolean success = examDAO.addExam(exam);

            if (success) {
                response.sendRedirect(
                        request.getContextPath() +
                        "/manage-exams.html?success=1");
            } else {
                showError(response, request,
                        "Failed to save the exam. Check the server logs.");
            }

        } catch (NumberFormatException e) {
            showError(response, request,
                    "Duration and total marks must be valid numbers.");
        } catch (DateTimeParseException e) {
            showError(response, request,
                    "Invalid date or time format.");
        }
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private void showError(
            HttpServletResponse response,
            HttpServletRequest request,
            String message) throws IOException {

        response.setContentType("text/html;charset=UTF-8");

        String safeMessage = message
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");

        response.getWriter().println(
                "<!DOCTYPE html><html><head><meta charset='UTF-8'>" +
                "<title>Exam Error</title></head><body>" +
                "<h2>" + safeMessage + "</h2>" +
                "<a href='" + request.getContextPath() +
                "/manage-exams.html'>Go Back</a>" +
                "</body></html>");
    }
}
