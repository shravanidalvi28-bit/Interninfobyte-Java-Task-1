package com.onlineexam.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onlineexam.dao.ExamDAO;
import com.onlineexam.model.Exam;

@WebServlet("/edit-exam")
public class EditExamServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(
                request.getParameter("id"));

        ExamDAO examDAO = new ExamDAO();

        Exam exam = examDAO.getExamById(id);

        if (exam == null) {

            response.getWriter().println(
                    "<h2>Exam not found!</h2>"
            );

            return;
        }

        request.setAttribute("exam", exam);

        request.getRequestDispatcher(
                "/edit-exam.jsp"
        ).forward(request, response);
    }


    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(
                request.getParameter("id"));

        String title = request.getParameter("title");

        String subject = request.getParameter("subject");

        int duration = Integer.parseInt(
                request.getParameter("duration"));

        int totalMarks = Integer.parseInt(
                request.getParameter("totalMarks"));

        Exam exam = new Exam();

        exam.setId(id);
        exam.setTitle(title);
        exam.setSubject(subject);
        exam.setDuration(duration);
        exam.setTotalMarks(totalMarks);

        ExamDAO examDAO = new ExamDAO();

        if (examDAO.updateExam(exam)) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/view-exams"
            );

        } else {

            response.getWriter().println(
                    "<h2>Failed to update exam!</h2>"
            );
        }
    }
}