package com.onlineexam.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onlineexam.dao.ExamDAO;

@WebServlet("/delete-exam")
public class DeleteExamServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(
                request.getParameter("id")
        );

        ExamDAO examDAO = new ExamDAO();

        boolean success = examDAO.deleteExam(id);

        if (success) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/view-exams"
            );

        } else {

            response.setContentType("text/html");

            response.getWriter().println(
                    "<h2>Failed to delete exam!</h2>" +
                    "<a href='view-exams'>Go Back</a>"
            );
        }
    }
}