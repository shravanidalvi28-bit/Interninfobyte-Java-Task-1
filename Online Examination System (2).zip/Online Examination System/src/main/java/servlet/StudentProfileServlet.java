package com.onlineexam.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineexam.model.User;

@WebServlet("/student-profile")
public class StudentProfileServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect("login.html");
            return;
        }

        String role = (String) session.getAttribute("role");

        if (role == null || !"STUDENT".equalsIgnoreCase(role)) {
            response.sendError(
                HttpServletResponse.SC_FORBIDDEN,
                "Access denied. Student access only."
            );
            return;
        }

        request.setAttribute("studentName", session.getAttribute("userName"));

        Object userObject = session.getAttribute("user");

        if (userObject instanceof User) {
            User user = (User) userObject;
            request.setAttribute("studentEmail", user.getEmail());
        } else {
            request.setAttribute("studentEmail", "Email unavailable");
        }

        request.getRequestDispatcher("/student-profile.jsp")
               .forward(request, response);
    }
}