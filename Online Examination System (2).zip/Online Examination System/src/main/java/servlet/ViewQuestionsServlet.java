package com.onlineexam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onlineexam.dao.QuestionDAO;
import com.onlineexam.model.Question;

@WebServlet("/view-questions")
public class ViewQuestionsServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        QuestionDAO questionDAO = new QuestionDAO();

        List<Question> questions =
                questionDAO.getAllQuestions();

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");

        out.println("<head>");

        out.println("<meta charset='UTF-8'>");
        out.println("<title>View Questions</title>");

        out.println("<style>");

        // BODY
        out.println("body {");
        out.println("font-family: Arial, sans-serif;");
        out.println("background: #f4f6f8;");
        out.println("margin: 0;");
        out.println("}");

        // HEADER
        out.println(".header {");
        out.println("background: #667eea;");
        out.println("color: white;");
        out.println("padding: 25px;");
        out.println("text-align: center;");
        out.println("}");

        // CONTAINER
        out.println(".container {");
        out.println("width: 95%;");
        out.println("margin: 30px auto;");
        out.println("}");

        // BACK LINK
        out.println(".back {");
        out.println("color: #667eea;");
        out.println("text-decoration: none;");
        out.println("font-size: 17px;");
        out.println("}");

        // TABLE
        out.println("table {");
        out.println("width: 100%;");
        out.println("border-collapse: collapse;");
        out.println("background: white;");
        out.println("margin-top: 25px;");
        out.println("box-shadow: 0 5px 20px rgba(0,0,0,0.1);");
        out.println("}");

        // TABLE HEADER
        out.println("th {");
        out.println("background: #667eea;");
        out.println("color: white;");
        out.println("padding: 12px;");
        out.println("}");

        // TABLE DATA
        out.println("td {");
        out.println("padding: 12px;");
        out.println("text-align: center;");
        out.println("border-bottom: 1px solid #ddd;");
        out.println("}");

        // ROW HOVER
        out.println("tr:hover {");
        out.println("background: #f8f9ff;");
        out.println("}");

        // QUESTION TEXT
        out.println(".question {");
        out.println("text-align: left;");
        out.println("max-width: 250px;");
        out.println("}");

        // EDIT BUTTON
        out.println(".edit-btn {");
        out.println("background: #667eea;");
        out.println("color: white;");
        out.println("padding: 7px 12px;");
        out.println("text-decoration: none;");
        out.println("border-radius: 5px;");
        out.println("}");

        // DELETE BUTTON
        out.println(".delete-btn {");
        out.println("background: #e74c3c;");
        out.println("color: white;");
        out.println("padding: 7px 12px;");
        out.println("text-decoration: none;");
        out.println("border-radius: 5px;");
        out.println("}");

        // HOVER
        out.println(".edit-btn:hover {");
        out.println("background: #5568d9;");
        out.println("}");

        out.println(".delete-btn:hover {");
        out.println("background: #c0392b;");
        out.println("}");

        out.println("</style>");

        out.println("</head>");

        out.println("<body>");

        // HEADER
        out.println("<div class='header'>");

        out.println("<h1>View Questions</h1>");

        out.println("<p>Online Examination System</p>");

        out.println("</div>");

        // CONTAINER
        out.println("<div class='container'>");

        // BACK LINK
        out.println("<a class='back' href='manage-questions.html'>");

        out.println("← Back to Manage Questions");

        out.println("</a>");

        // TABLE
        out.println("<table>");

        // TABLE HEADER
        out.println("<tr>");

        out.println("<th>ID</th>");
        out.println("<th>Exam ID</th>");
        out.println("<th>Question</th>");
        out.println("<th>Option A</th>");
        out.println("<th>Option B</th>");
        out.println("<th>Option C</th>");
        out.println("<th>Option D</th>");
        out.println("<th>Correct Answer</th>");
        out.println("<th>Marks</th>");
        out.println("<th>Action</th>");

        out.println("</tr>");

        // DISPLAY QUESTIONS
        for (Question question : questions) {

            out.println("<tr>");

            out.println(
                    "<td>" +
                    question.getId() +
                    "</td>"
            );

            out.println(
                    "<td>" +
                    question.getExamId() +
                    "</td>"
            );

            out.println(
                    "<td class='question'>" +
                    question.getQuestionText() +
                    "</td>"
            );

            out.println(
                    "<td>" +
                    question.getOptionA() +
                    "</td>"
            );

            out.println(
                    "<td>" +
                    question.getOptionB() +
                    "</td>"
            );

            out.println(
                    "<td>" +
                    question.getOptionC() +
                    "</td>"
            );

            out.println(
                    "<td>" +
                    question.getOptionD() +
                    "</td>"
            );

            out.println(
                    "<td>" +
                    question.getCorrectAnswer() +
                    "</td>"
            );

            out.println(
                    "<td>" +
                    question.getMarks() +
                    "</td>"
            );

            // ACTION
            out.println("<td>");

            // EDIT
            out.println(
                    "<a class='edit-btn' " +
                    "href='edit-question?id=" +
                    question.getId() +
                    "'>Edit</a> "
            );

            // DELETE
            out.println(
                    "<a class='delete-btn' " +
                    "href='delete-question?id=" +
                    question.getId() +
                    "' " +
                    "onclick=\"return confirm(" +
                    "'Are you sure you want to delete this question?'" +
                    ");\">" +
                    "Delete</a>"
            );

            out.println("</td>");

            out.println("</tr>");
        }

        out.println("</table>");

        out.println("</div>");

        out.println("</body>");

        out.println("</html>");
    }
}