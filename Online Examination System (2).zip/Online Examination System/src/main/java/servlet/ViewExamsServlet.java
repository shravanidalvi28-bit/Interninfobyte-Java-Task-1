package com.onlineexam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onlineexam.dao.ExamDAO;
import com.onlineexam.model.Exam;

@WebServlet("/view-exams")
public class ViewExamsServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        ExamDAO examDAO = new ExamDAO();

        List<Exam> exams = examDAO.getAllExams();

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");

        out.println("<meta charset='UTF-8'>");
        out.println("<title>View Exams</title>");

        out.println("<style>");

        // BODY
        out.println("body {");
        out.println("font-family: Arial, sans-serif;");
        out.println("background: #f4f6f8;");
        out.println("margin: 0;");
        out.println("}");

        // HEADER
        out.println(".header {");
        out.println("background: #667eea;");
        out.println("color: white;");
        out.println("padding: 25px;");
        out.println("text-align: center;");
        out.println("}");

        // CONTAINER
        out.println(".container {");
        out.println("width: 90%;");
        out.println("margin: 30px auto;");
        out.println("}");

        // BACK BUTTON
        out.println(".back {");
        out.println("color: #667eea;");
        out.println("text-decoration: none;");
        out.println("font-size: 17px;");
        out.println("}");

        // TABLE
        out.println("table {");
        out.println("width: 100%;");
        out.println("border-collapse: collapse;");
        out.println("background: white;");
        out.println("margin-top: 25px;");
        out.println("box-shadow: 0 5px 20px rgba(0,0,0,0.1);");
        out.println("}");

        // TABLE HEADER
        out.println("th {");
        out.println("background: #667eea;");
        out.println("color: white;");
        out.println("padding: 15px;");
        out.println("}");

        // TABLE DATA
        out.println("td {");
        out.println("padding: 15px;");
        out.println("text-align: center;");
        out.println("border-bottom: 1px solid #ddd;");
        out.println("}");

        // ROW HOVER
        out.println("tr:hover {");
        out.println("background: #f8f9ff;");
        out.println("}");

        // EDIT BUTTON
        out.println(".edit-btn {");
        out.println("background: #667eea;");
        out.println("color: white;");
        out.println("padding: 8px 15px;");
        out.println("text-decoration: none;");
        out.println("border-radius: 5px;");
        out.println("}");

        // DELETE BUTTON
        out.println(".delete-btn {");
        out.println("background: #e74c3c;");
        out.println("color: white;");
        out.println("padding: 8px 15px;");
        out.println("text-decoration: none;");
        out.println("border-radius: 5px;");
        out.println("}");

        // BUTTON HOVER
        out.println(".edit-btn:hover {");
        out.println("background: #5568d9;");
        out.println("}");

        out.println(".delete-btn:hover {");
        out.println("background: #c0392b;");
        out.println("}");

        out.println("</style>");

        out.println("</head>");

        out.println("<body>");

        // HEADER
        out.println("<div class='header'>");
        out.println("<h1>View Exams</h1>");
        out.println("<p>Online Examination System</p>");
        out.println("</div>");

        // CONTAINER
        out.println("<div class='container'>");

        // BACK LINK
        out.println("<a class='back' href='manage-exams.html'>");
        out.println("← Back to Manage Exams");
        out.println("</a>");

        // TABLE
        out.println("<table>");

        out.println("<tr>");
        out.println("<th>ID</th>");
        out.println("<th>Exam Title</th>");
        out.println("<th>Subject</th>");
        out.println("<th>Duration</th>");
        out.println("<th>Total Marks</th>");
        out.println("<th>Action</th>");
        out.println("</tr>");

        // DISPLAY EXAMS
        for (Exam exam : exams) {

            out.println("<tr>");

            out.println(
                    "<td>" +
                    exam.getId() +
                    "</td>"
            );

            out.println(
                    "<td>" +
                    exam.getTitle() +
                    "</td>"
            );

            out.println(
                    "<td>" +
                    exam.getSubject() +
                    "</td>"
            );

            out.println(
                    "<td>" +
                    exam.getDuration() +
                    " minutes</td>"
            );

            out.println(
                    "<td>" +
                    exam.getTotalMarks() +
                    "</td>"
            );

            // ACTION COLUMN
            out.println("<td>");

            // EDIT BUTTON
            out.println(
                    "<a class='edit-btn' " +
                    "href='edit-exam?id=" +
                    exam.getId() +
                    "'>Edit</a> "
            );

            // DELETE BUTTON
            out.println(
                    "<a class='delete-btn' " +
                    "href='delete-exam?id=" +
                    exam.getId() +
                    "' " +
                    "onclick=\"return confirm(" +
                    "'Are you sure you want to delete this exam?'" +
                    ");\">" +
                    "Delete</a>"
            );

            out.println("</td>");

            out.println("</tr>");
        }

        out.println("</table>");

        out.println("</div>");

        out.println("</body>");

        out.println("</html>");
    }
}