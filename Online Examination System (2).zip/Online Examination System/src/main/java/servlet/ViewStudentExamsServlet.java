
package com.onlineexam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineexam.dao.ExamDAO;
import com.onlineexam.dao.ResultDAO;
import com.onlineexam.model.Exam;

@WebServlet("/view-student-exams")
public class ViewStudentExamsServlet extends HttpServlet {

    private final ExamDAO examDAO = new ExamDAO();
    private final ResultDAO resultDAO = new ResultDAO();

    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a");

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null
                || !"STUDENT".equals(session.getAttribute("role"))
                || session.getAttribute("userId") == null) {

            response.sendRedirect(
                    request.getContextPath() + "/login.html");
            return;
        }

        int userId = (Integer) session.getAttribute("userId");

        response.setContentType("text/html;charset=UTF-8");
        response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
        response.setHeader("Pragma", "no-cache");

        List<Exam> exams = examDAO.getAllExams();
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html><html lang='en'><head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1'>");
        out.println("<title>Available Exams</title>");

        out.println("<style>");
        out.println("*{box-sizing:border-box}");
        out.println("body{font-family:Arial,sans-serif;background:#f4f6f8;margin:0;color:#333}");
        out.println(".header{background:#667eea;color:white;padding:25px;text-align:center}");
        out.println(".container{width:90%;max-width:1200px;margin:35px auto}");
        out.println(".back{color:#667eea;text-decoration:none;font-size:16px}");
        out.println(".exam-container{display:flex;flex-wrap:wrap;gap:22px;margin-top:28px}");
        out.println(".exam-card{background:white;width:300px;max-width:100%;padding:24px;border-radius:12px;box-shadow:0 5px 15px #0001}");
        out.println(".exam-card h2{color:#667eea;overflow-wrap:anywhere}");
        out.println(".exam-card p{color:#555;overflow-wrap:anywhere}");
        out.println(".status{display:inline-block;padding:7px 11px;border-radius:20px;font-size:13px;font-weight:bold;margin:8px 0}");
        out.println(".available{background:#dcfce7;color:#166534}");
        out.println(".upcoming{background:#fef3c7;color:#92400e}");
        out.println(".closed{background:#fee2e2;color:#991b1b}");
        out.println(".attempted{background:#e5e7eb;color:#374151}");
        out.println(".unscheduled{background:#f3e8ff;color:#6b21a8}");
        out.println(".start-btn{display:inline-block;background:#667eea;color:white;padding:11px 18px;text-decoration:none;border-radius:6px;margin-top:10px}");
        out.println(".start-btn:hover{background:#5568d9}");
        out.println(".disabled-btn{display:inline-block;background:#d1d5db;color:#4b5563;padding:11px 18px;border-radius:6px;margin-top:10px}");
        out.println(".no-exams{background:white;padding:30px;text-align:center;border-radius:10px;width:100%}");
        out.println("</style></head><body>");

        out.println("<div class='header'><h1>Available Exams</h1>");
        out.println("<p>Online Examination System</p></div>");

        out.println("<div class='container'>");
        out.println("<a class='back' href='" +
                request.getContextPath() +
                "/student.html'>← Back to Student Dashboard</a>");

        out.println("<div class='exam-container'>");

        if (exams == null || exams.isEmpty()) {

            out.println("<div class='no-exams'>");
            out.println("<h2>No Exams Available</h2>");
            out.println("<p>Please check again later.</p></div>");

        } else {

            try {
                // Use one consistent Java time snapshot for this request.
                LocalDateTime now = LocalDateTime.now();

                // Diagnostic log: compare Java time with MySQL exam times.
                System.out.println(
                        "[EXAM DEBUG] Java current time: " + now);

                for (Exam exam : exams) {

                    boolean attempted = resultDAO.hasAttemptedExam(
                            userId, exam.getId());

                    LocalDateTime start = exam.getStartTime();
                    LocalDateTime end = exam.getEndTime();

                    System.out.println(
                            "[EXAM DEBUG] ID=" + exam.getId()
                            + ", title=" + exam.getTitle()
                            + ", start=" + start
                            + ", end=" + end
                            + ", now=" + now
                            + ", attempted=" + attempted);

                    String status;
                    String statusClass;
                    boolean canStart = false;

                    if (attempted) {
                        status = "Already Attempted";
                        statusClass = "attempted";

                    } else if (start == null || end == null
                            || !end.isAfter(start)) {
                        status = "Not Scheduled";
                        statusClass = "unscheduled";

                    } else if (now.isBefore(start)) {
                        status = "Upcoming";
                        statusClass = "upcoming";

                    } else if (!now.isBefore(end)) {
                        status = "Closed";
                        statusClass = "closed";

                    } else {
                        status = "Available Now";
                        statusClass = "available";
                        canStart = true;
                    }

                    out.println("<div class='exam-card'>");

                    out.println("<h2>" +
                            escapeHtml(exam.getTitle()) + "</h2>");

                    out.println("<p><strong>Subject:</strong> " +
                            escapeHtml(exam.getSubject()) + "</p>");

                    out.println("<p><strong>Duration:</strong> " +
                            exam.getDuration() + " minutes</p>");

                    out.println("<p><strong>Total Marks:</strong> " +
                            exam.getTotalMarks() + "</p>");

                    out.println("<p><strong>Starts:</strong> " +
                            (start == null ? "Not set" :
                            start.format(FORMATTER)) + "</p>");

                    out.println("<p><strong>Ends:</strong> " +
                            (end == null ? "Not set" :
                            end.format(FORMATTER)) + "</p>");

                    out.println("<span class='status " +
                            statusClass + "'>" +
                            status + "</span><br>");

                    if (canStart) {
                        out.println("<a class='start-btn' href='" +
                                request.getContextPath() +
                                "/start-exam?id=" +
                                exam.getId() +
                                "'>Start Exam</a>");
                    } else {
                        out.println("<span class='disabled-btn'>Start Exam</span>");
                    }

                    out.println("</div>");
                }

            } catch (RuntimeException e) {
                log("Unable to load exam attempt statuses.", e);

                response.reset();
                response.setContentType("text/html;charset=UTF-8");
                response.setStatus(
                        HttpServletResponse.SC_INTERNAL_SERVER_ERROR);

                out.println("<h2>Unable to load exam statuses.</h2>");
                out.println("<p>Check the Tomcat console for details.</p>");
                return;
            }
        }

        out.println("</div></div></body></html>");
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
