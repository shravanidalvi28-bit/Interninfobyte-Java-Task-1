package com.onlineexam.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onlineexam.dao.QuestionDAO;
import com.onlineexam.model.Question;

@WebServlet("/add-question")
public class AddQuestionServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Get form data
        int examId = Integer.parseInt(
                request.getParameter("examId")
        );

        String questionText =
                request.getParameter("questionText");

        String optionA =
                request.getParameter("optionA");

        String optionB =
                request.getParameter("optionB");

        String optionC =
                request.getParameter("optionC");

        String optionD =
                request.getParameter("optionD");

        String correctAnswer =
                request.getParameter("correctAnswer");

        int marks = Integer.parseInt(
                request.getParameter("marks")
        );

        // Create Question object
        Question question = new Question();

        question.setExamId(examId);
        question.setQuestionText(questionText);
        question.setOptionA(optionA);
        question.setOptionB(optionB);
        question.setOptionC(optionC);
        question.setOptionD(optionD);
        question.setCorrectAnswer(correctAnswer);
        question.setMarks(marks);

        // Save question
        QuestionDAO questionDAO = new QuestionDAO();

        boolean success =
                questionDAO.addQuestion(question);

        // Check result
        if (success) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/view-questions"
            );

        } else {

            response.setContentType("text/html");

            response.getWriter().println(
                    "<html>" +
                    "<head><title>Add Question</title></head>" +
                    "<body>" +
                    "<h2>Failed to add question!</h2>" +
                    "<a href='manage-questions.html'>Go Back</a>" +
                    "</body>" +
                    "</html>"
            );
        }
    }
}