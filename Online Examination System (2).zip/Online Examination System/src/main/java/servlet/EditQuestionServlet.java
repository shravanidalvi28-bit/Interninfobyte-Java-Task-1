package com.onlineexam.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onlineexam.dao.QuestionDAO;
import com.onlineexam.model.Question;

@WebServlet("/edit-question")
public class EditQuestionServlet extends HttpServlet {

    // =========================
    // OPEN EDIT PAGE
    // =========================
    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(
                request.getParameter("id")
        );

        QuestionDAO questionDAO = new QuestionDAO();

        Question question =
                questionDAO.getQuestionById(id);

        if (question == null) {

            response.getWriter().println(
                    "<h2>Question not found!</h2>"
            );

            return;
        }

        request.setAttribute(
                "question",
                question
        );

        request.getRequestDispatcher(
                "/edit-question.jsp"
        ).forward(request, response);
    }


    // =========================
    // UPDATE QUESTION
    // =========================
    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(
                request.getParameter("id")
        );

        int examId = Integer.parseInt(
                request.getParameter("examId")
        );

        String questionText =
                request.getParameter("questionText");

        String optionA =
                request.getParameter("optionA");

        String optionB =
                request.getParameter("optionB");

        String optionC =
                request.getParameter("optionC");

        String optionD =
                request.getParameter("optionD");

        String correctAnswer =
                request.getParameter("correctAnswer");

        int marks = Integer.parseInt(
                request.getParameter("marks")
        );

        Question question = new Question();

        question.setId(id);
        question.setExamId(examId);
        question.setQuestionText(questionText);
        question.setOptionA(optionA);
        question.setOptionB(optionB);
        question.setOptionC(optionC);
        question.setOptionD(optionD);
        question.setCorrectAnswer(correctAnswer);
        question.setMarks(marks);

        QuestionDAO questionDAO =
                new QuestionDAO();

        boolean success =
                questionDAO.updateQuestion(question);

        if (success) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/view-questions"
            );

        } else {

            response.setContentType(
                    "text/html;charset=UTF-8"
            );

            response.getWriter().println(
                    "<h2>Failed to update question!</h2>" +
                    "<a href='view-questions'>Go Back</a>"
            );
        }
    }
}