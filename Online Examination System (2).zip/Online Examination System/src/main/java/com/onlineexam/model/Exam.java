
package com.onlineexam.model;

import java.time.LocalDateTime;

public class Exam {

    private int id;
    private String title;
    private String subject;
    private int duration;
    private int totalMarks;
    private LocalDateTime startTime;
    private LocalDateTime endTime;

    public Exam() {
    }

    // Existing constructor preserved for compatibility
    public Exam(int id, String title, String subject,
                int duration, int totalMarks) {
        this.id = id;
        this.title = title;
        this.subject = subject;
        this.duration = duration;
        this.totalMarks = totalMarks;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getTotalMarks() {
        return totalMarks;
    }

    public void setTotalMarks(int totalMarks) {
        this.totalMarks = totalMarks;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }
}
