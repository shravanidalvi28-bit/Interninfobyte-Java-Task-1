
package com.onlineexam.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.onlineexam.dao.ResultDAO;
import com.onlineexam.model.Result;

@WebServlet("/my-results")
public class MyResultsServlet extends HttpServlet {

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null
                || session.getAttribute("userId") == null
                || !"STUDENT".equalsIgnoreCase(
                        String.valueOf(session.getAttribute("role")))) {

            response.sendRedirect(
                    request.getContextPath() + "/login.html");
            return;
        }

        int studentId = Integer.parseInt(
                String.valueOf(session.getAttribute("userId")));

        ResultDAO resultDAO = new ResultDAO();

        List<Result> results =
                resultDAO.getResultsByStudentId(studentId);

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html><head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<title>My Results</title>");

        out.println("<style>");
        out.println("body{font-family:Arial,sans-serif;background:#f4f6f8;margin:0;color:#333;}");
        out.println(".header{background:#667eea;color:white;padding:25px;text-align:center;}");
        out.println(".container{width:90%;max-width:1100px;margin:35px auto;}");
        out.println(".back{color:#667eea;text-decoration:none;font-size:16px;}");
        out.println(".card{background:white;padding:25px;margin-top:25px;border-radius:12px;box-shadow:0 5px 15px rgba(0,0,0,.08);}");
        out.println("table{width:100%;border-collapse:collapse;margin-top:20px;background:white;}");
        out.println("th{background:#667eea;color:white;padding:14px;text-align:left;}");
        out.println("td{padding:14px;border-bottom:1px solid #ddd;}");
        out.println("tr:hover{background:#f8f9ff;}");
        out.println(".score{font-weight:bold;color:#4b61d1;}");
        out.println(".empty{text-align:center;padding:30px;}");
        out.println("</style>");

        out.println("</head><body>");

        out.println("<div class='header'>");
        out.println("<h1>My Examination Results</h1>");
        out.println("<p>Online Examination System</p>");
        out.println("</div>");

        out.println("<div class='container'>");
        out.println("<a class='back' href='student.html'>&larr; Back to Student Dashboard</a>");

        out.println("<div class='card'>");

        if (results.isEmpty()) {

            out.println("<div class='empty'>");
            out.println("<h2>No Results Available</h2>");
            out.println("<p>Your completed exam results will appear here.</p>");
            out.println("</div>");

        } else {

            out.println("<h2>Your Results</h2>");
            out.println("<table>");

            out.println("<tr>");
            out.println("<th>Exam</th>");
            out.println("<th>Score</th>");
            out.println("<th>Total Marks</th>");
            out.println("<th>Submitted At</th>");
            out.println("</tr>");

            for (Result result : results) {

                out.println("<tr>");

                out.println("<td>"
                        + escapeHtml(result.getExamTitle())
                        + "</td>");

                out.println("<td class='score'>"
                        + result.getScore()
                        + "</td>");

                out.println("<td>"
                        + result.getTotalMarks()
                        + "</td>");

                out.println("<td>"
                        + escapeHtml(result.getSubmittedAt())
                        + "</td>");

                out.println("</tr>");
            }

            out.println("</table>");
        }

        out.println("</div></div></body></html>");
    }

    private String escapeHtml(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#x27;");
    }
}
