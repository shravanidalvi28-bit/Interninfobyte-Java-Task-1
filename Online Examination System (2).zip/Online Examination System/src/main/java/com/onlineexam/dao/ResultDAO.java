
package com.onlineexam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.onlineexam.model.Result;
import com.onlineexam.util.DBConnection;

public class ResultDAO {

    // SAVE EXAM RESULT
    public boolean saveResult(
            int studentId,
            int examId,
            int score,
            int totalMarks) {

        String sql =
                "INSERT INTO results " +
                "(user_id, exam_id, score, total_marks) " +
                "VALUES (?, ?, ?, ?)";

        try (
            Connection connection = DBConnection.getConnection();
            PreparedStatement statement =
                    connection.prepareStatement(sql)
        ) {
            statement.setInt(1, studentId);
            statement.setInt(2, examId);
            statement.setInt(3, score);
            statement.setInt(4, totalMarks);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // GET RESULTS FOR ONE STUDENT
    public List<Result> getResultsByStudentId(int studentId) {

        List<Result> results = new ArrayList<>();

        String sql =
                "SELECT r.id, r.user_id, r.exam_id, " +
                "e.title AS exam_title, r.score, " +
                "r.total_marks, r.submitted_at " +
                "FROM results r " +
                "INNER JOIN exams e ON r.exam_id = e.id " +
                "WHERE r.user_id = ? " +
                "ORDER BY r.submitted_at DESC";

        try (
            Connection connection = DBConnection.getConnection();
            PreparedStatement statement =
                    connection.prepareStatement(sql)
        ) {
            statement.setInt(1, studentId);

            try (ResultSet rs = statement.executeQuery()) {

                while (rs.next()) {
                    Result result = new Result();

                    result.setId(rs.getInt("id"));
                    result.setUserId(rs.getInt("user_id"));
                    result.setExamId(rs.getInt("exam_id"));
                    result.setExamTitle(
                            rs.getString("exam_title"));
                    result.setScore(rs.getInt("score"));
                    result.setTotalMarks(
                            rs.getInt("total_marks"));
                    result.setSubmittedAt(
                            rs.getString("submitted_at"));

                    results.add(result);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return results;
    }
    
    // CHECK WHETHER STUDENT HAS ALREADY ATTEMPTED EXAM
    public boolean hasAttemptedExam(int userId, int examId) {

        String sql =
                "SELECT COUNT(*) FROM results " +
                "WHERE user_id = ? AND exam_id = ?";

        try (
            Connection connection = DBConnection.getConnection();
            PreparedStatement statement =
                    connection.prepareStatement(sql)
        ) {
            statement.setInt(1, userId);
            statement.setInt(2, examId);

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(
                    "Unable to check previous exam attempt.", e);
        }

        return false;
    }

}
