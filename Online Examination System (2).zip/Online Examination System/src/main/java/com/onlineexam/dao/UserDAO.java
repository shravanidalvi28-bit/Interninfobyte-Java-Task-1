
package com.onlineexam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.onlineexam.model.User;
import com.onlineexam.util.DBConnection;

public class UserDAO {

    public User login(String email, String password) {

        if (email == null || password == null) {
            return null;
        }

        email = email.trim();

        String sql =
            "SELECT id, name, email, password, role " +
            "FROM users WHERE email = ? AND password = ?";

        try (
            Connection connection = DBConnection.getConnection();
            PreparedStatement statement =
                connection.prepareStatement(sql)
        ) {

            statement.setString(1, email);
            statement.setString(2, password);

            try (ResultSet result = statement.executeQuery()) {

                if (result.next()) {

                    User user = new User();

                    user.setId(result.getInt("id"));
                    user.setName(result.getString("name"));
                    user.setEmail(result.getString("email"));
                    user.setPassword(result.getString("password"));
                    user.setRole(result.getString("role"));

                    return user;
                }
            }

        } catch (Exception e) {
            System.err.println("Login database error:");
            e.printStackTrace();
        }

        return null;
    }
}
