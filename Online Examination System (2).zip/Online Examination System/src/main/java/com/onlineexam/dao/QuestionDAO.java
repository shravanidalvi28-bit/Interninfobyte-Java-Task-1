
package com.onlineexam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.onlineexam.model.Question;
import com.onlineexam.util.DBConnection;

public class QuestionDAO {

    // Create a Question object from the current database row
    private Question mapQuestion(ResultSet rs) throws SQLException {

        Question question = new Question();

        question.setId(rs.getInt("id"));
        question.setExamId(rs.getInt("exam_id"));
        question.setQuestionText(rs.getString("question_text"));
        question.setOptionA(rs.getString("option_a"));
        question.setOptionB(rs.getString("option_b"));
        question.setOptionC(rs.getString("option_c"));
        question.setOptionD(rs.getString("option_d"));
        question.setCorrectAnswer(rs.getString("correct_option"));
        question.setMarks(rs.getInt("marks"));

        return question;
    }

    // ADD QUESTION
    public boolean addQuestion(Question question) {

        String sql = "INSERT INTO questions "
                + "(exam_id, question_text, option_a, option_b, "
                + "option_c, option_d, correct_option, marks) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {
            ps.setInt(1, question.getExamId());
            ps.setString(2, question.getQuestionText());
            ps.setString(3, question.getOptionA());
            ps.setString(4, question.getOptionB());
            ps.setString(5, question.getOptionC());
            ps.setString(6, question.getOptionD());
            ps.setString(7, question.getCorrectAnswer());
            ps.setInt(8, question.getMarks());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Failed to add question.", e);
        }
    }

    // VIEW ALL QUESTIONS
    public List<Question> getAllQuestions() {

        List<Question> questions = new ArrayList<>();
        String sql = "SELECT * FROM questions ORDER BY id";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                questions.add(mapQuestion(rs));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Failed to load questions.", e);
        }

        return questions;
    }

    // GET QUESTION BY ID
    public Question getQuestionById(int id) {

        String sql = "SELECT * FROM questions WHERE id = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {
            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapQuestion(rs);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException(
                    "Failed to load question ID " + id, e);
        }

        return null;
    }

    // GET QUESTIONS BY EXAM ID
    public List<Question> getQuestionsByExamId(int examId) {

        List<Question> questions = new ArrayList<>();

        String sql =
                "SELECT * FROM questions WHERE exam_id = ? ORDER BY id";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {
            ps.setInt(1, examId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    questions.add(mapQuestion(rs));
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException(
                    "Failed to load questions for exam ID " + examId, e);
        }

        return questions;
    }

    // UPDATE QUESTION
    public boolean updateQuestion(Question question) {

        String sql = "UPDATE questions SET "
                + "exam_id = ?, question_text = ?, option_a = ?, "
                + "option_b = ?, option_c = ?, option_d = ?, "
                + "correct_option = ?, marks = ? WHERE id = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {
            ps.setInt(1, question.getExamId());
            ps.setString(2, question.getQuestionText());
            ps.setString(3, question.getOptionA());
            ps.setString(4, question.getOptionB());
            ps.setString(5, question.getOptionC());
            ps.setString(6, question.getOptionD());
            ps.setString(7, question.getCorrectAnswer());
            ps.setInt(8, question.getMarks());
            ps.setInt(9, question.getId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException(
                    "Failed to update question ID "
                    + question.getId(), e);
        }
    }

    // DELETE QUESTION
    public boolean deleteQuestion(int id) {

        String sql = "DELETE FROM questions WHERE id = ?";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql)
        ) {
            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException(
                    "Failed to delete question ID " + id, e);
        }
    }
}
