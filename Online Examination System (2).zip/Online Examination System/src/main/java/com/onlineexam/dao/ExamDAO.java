
package com.onlineexam.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.onlineexam.model.Exam;
import com.onlineexam.util.DBConnection;

public class ExamDAO {

    // ADD EXAM
    public boolean addExam(Exam exam) {

        String sql = "INSERT INTO exams " +
                "(title, subject, duration, total_marks, " +
                "start_time, end_time) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(1, exam.getTitle());
            statement.setString(2, exam.getSubject());
            statement.setInt(3, exam.getDuration());
            statement.setInt(4, exam.getTotalMarks());

            setDateTime(statement, 5, exam.getStartTime());
            setDateTime(statement, 6, exam.getEndTime());

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // VIEW ALL EXAMS
    public List<Exam> getAllExams() {

        List<Exam> exams = new ArrayList<>();
        String sql = "SELECT * FROM exams ORDER BY id DESC";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {

            while (result.next()) {
                exams.add(mapExam(result));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return exams;
    }

    // GET EXAM BY ID
    public Exam getExamById(int id) {

        String sql = "SELECT * FROM exams WHERE id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, id);

            try (ResultSet result = statement.executeQuery()) {
                if (result.next()) {
                    return mapExam(result);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    // UPDATE EXAM
    public boolean updateExam(Exam exam) {

        String sql = "UPDATE exams SET " +
                "title = ?, subject = ?, duration = ?, " +
                "total_marks = ?, start_time = ?, end_time = ? " +
                "WHERE id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(1, exam.getTitle());
            statement.setString(2, exam.getSubject());
            statement.setInt(3, exam.getDuration());
            statement.setInt(4, exam.getTotalMarks());

            setDateTime(statement, 5, exam.getStartTime());
            setDateTime(statement, 6, exam.getEndTime());

            statement.setInt(7, exam.getId());

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // DELETE EXAM
    public boolean deleteExam(int id) {

        String sql = "DELETE FROM exams WHERE id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, id);

            return statement.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // MAP DATABASE ROW TO EXAM OBJECT
    private Exam mapExam(ResultSet result) throws Exception {

        Exam exam = new Exam();

        exam.setId(result.getInt("id"));
        exam.setTitle(result.getString("title"));
        exam.setSubject(result.getString("subject"));
        exam.setDuration(result.getInt("duration"));
        exam.setTotalMarks(result.getInt("total_marks"));

        Timestamp start = result.getTimestamp("start_time");
        Timestamp end = result.getTimestamp("end_time");

        exam.setStartTime(
                start == null ? null : start.toLocalDateTime());

        exam.setEndTime(
                end == null ? null : end.toLocalDateTime());

        return exam;
    }

    // HANDLE OPTIONAL DATE/TIME VALUES
    private void setDateTime(PreparedStatement statement,
                             int index,
                             LocalDateTime value) throws Exception {

        if (value == null) {
            statement.setNull(index, Types.TIMESTAMP);
        } else {
            statement.setTimestamp(
                    index, Timestamp.valueOf(value));
        }
    }
}
