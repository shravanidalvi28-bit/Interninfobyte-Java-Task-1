
<%@ page import="java.util.List" %>
<%@ page import="com.onlineexam.model.Exam" %>
<%@ page import="com.onlineexam.model.Question" %>

<%
    Exam exam = (Exam) request.getAttribute("exam");
    List<Question> questions =
        (List<Question>) request.getAttribute("questions");

    Long remaining = (Long) request.getAttribute("remainingSeconds");
%>

<!DOCTYPE html>
<html lang="en">
<head>
    
<link rel="stylesheet"
      href="${pageContext.request.contextPath}/css/style.css">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Exam</title>

    <style>
        * { box-sizing: border-box; }

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
            color: #333;
        }

        .header {
            background: #667eea;
            color: white;
            padding: 25px;
            text-align: center;
        }

        .container {
            width: 75%;
            max-width: 1100px;
            margin: 30px auto;
        }

        .info, .question-card {
            background: white;
            padding: 25px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
        }

        .info h2 { color: #667eea; }

        .timer {
            position: sticky;
            top: 10px;
            z-index: 1000;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            background: #e63946;
            color: white;
            padding: 15px 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .timer.warning { background: #b45309; }

        .question-text {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .option {
            display: block;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 6px;
            cursor: pointer;
        }

        .option:hover { background: #f0f2ff; }
        .option input { margin-right: 8px; }

        .submit-btn {
            width: 100%;
            padding: 15px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 7px;
            font-size: 17px;
            cursor: pointer;
        }

        .submit-btn:hover { background: #5568d9; }

        .submit-btn:disabled {
            background: #999;
            cursor: not-allowed;
        }

        .no-questions {
            background: white;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
        }

        @media (max-width: 768px) {
            .container { width: 92%; }
            .info, .question-card { padding: 18px; }
            .timer { font-size: 16px; }
        }
    </style>
</head>

<body>

<div class="header">
    <h1><%= exam.getTitle() %></h1>
    <p>Online Examination System</p>
</div>

<div class="container">

    <div class="info">
        <h2><%= exam.getTitle() %></h2>
        <p><strong>Subject:</strong> <%= exam.getSubject() %></p>
        <p><strong>Duration:</strong> <%= exam.getDuration() %> minutes</p>
        <p><strong>Total Marks:</strong> <%= exam.getTotalMarks() %></p>
    </div>

    <% if (questions == null || questions.isEmpty()) { %>

        <div class="no-questions">
            <h2>No Questions Available</h2>
            <p>Please ask the administrator to add questions.</p>
        </div>

    <% } else if (remaining == null || remaining <= 0) { %>

        <div class="no-questions">
            <h2>Exam Time Expired</h2>
            <p>Your remaining exam time has expired.</p>
            <a href="<%= request.getContextPath() %>/view-student-exams">
                Back to Available Exams
            </a>
        </div>

    <% } else { %>

        <div class="timer" id="timerBox">
            <span>⏱ Time Remaining</span>
            <span id="time" role="timer" aria-live="off">Loading...</span>
        </div>

        <form id="examForm"
              action="<%= request.getContextPath() %>/submit-exam"
              method="post">

            <input type="hidden" name="examId"
                   value="<%= exam.getId() %>">

            <% int number = 1;
               for (Question q : questions) { %>

                <div class="question-card">

                    <div class="question-text">
                        Q<%= number++ %>. <%= q.getQuestionText() %>
                    </div>

                    <p><strong>Marks:</strong> <%= q.getMarks() %></p>

                    <label class="option">
                        <input type="radio"
                               name="question_<%= q.getId() %>"
                               value="A">
                        A. <%= q.getOptionA() %>
                    </label>

                    <label class="option">
                        <input type="radio"
                               name="question_<%= q.getId() %>"
                               value="B">
                        B. <%= q.getOptionB() %>
                    </label>

                    <label class="option">
                        <input type="radio"
                               name="question_<%= q.getId() %>"
                               value="C">
                        C. <%= q.getOptionC() %>
                    </label>

                    <label class="option">
                        <input type="radio"
                               name="question_<%= q.getId() %>"
                               value="D">
                        D. <%= q.getOptionD() %>
                    </label>

                </div>

            <% } %>

            <button class="submit-btn" id="submitBtn" type="submit">
                Submit Exam
            </button>
        </form>

    <% } %>

</div>

<% if (questions != null && !questions.isEmpty()
       && remaining != null && remaining > 0) { %>

<script>
    // Initial value comes from the server.
    let timeLeft = Math.max(
        0,
        Number("<%= remaining %>")
    );

    const timerDisplay = document.getElementById("time");
    const timerBox = document.getElementById("timerBox");
    const examForm = document.getElementById("examForm");
    const submitBtn = document.getElementById("submitBtn");

    let timerInterval = null;
    let submitted = false;

    // Use elapsed browser time instead of counting interval callbacks.
    let lastTick = Date.now();

    function formatTime(seconds) {
        seconds = Math.max(0, Math.ceil(seconds));

        const minutes = Math.floor(seconds / 60);
        const remainingSeconds = seconds % 60;

        return String(minutes).padStart(2, "0") + ":" +
               String(remainingSeconds).padStart(2, "0");
    }

    function submitExamAutomatically() {
        if (submitted) {
            return;
        }

        submitted = true;

        if (timerInterval !== null) {
            clearInterval(timerInterval);
        }

        timerDisplay.textContent = "00:00";
        submitBtn.disabled = true;
        submitBtn.textContent = "Submitting Exam...";

        alert("Time is up! Your exam is being submitted.");

        // The server independently validates the deadline.
        examForm.submit();
    }

    function updateTimer() {
        const now = Date.now();
        const elapsed = (now - lastTick) / 1000;

        timeLeft -= elapsed;
        lastTick = now;

        timerDisplay.textContent = formatTime(timeLeft);

        if (timeLeft <= 60) {
            timerBox.classList.add("warning");
        }

        if (timeLeft <= 0) {
            timeLeft = 0;
            submitExamAutomatically();
        }
    }

    examForm.addEventListener("submit", function(event) {
        if (submitted) {
            event.preventDefault();
            return;
        }

        updateTimer();

        if (timeLeft <= 0) {
            event.preventDefault();
            submitExamAutomatically();
            return;
        }

        if (!confirm("Are you sure you want to submit the exam?")) {
            event.preventDefault();
            return;
        }

        submitted = true;

        if (timerInterval !== null) {
            clearInterval(timerInterval);
        }

        submitBtn.disabled = true;
        submitBtn.textContent = "Submitting Exam...";
    });

    // Display the correct remaining time immediately.
    timerDisplay.textContent = formatTime(timeLeft);

    if (timeLeft <= 60) {
        timerBox.classList.add("warning");
    }

    timerInterval = setInterval(updateTimer, 1000);
</script>

<% } %>

</body>
</html>
