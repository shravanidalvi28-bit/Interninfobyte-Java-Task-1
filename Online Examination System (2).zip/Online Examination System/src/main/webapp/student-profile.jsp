﻿
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Profile | Online Examination System</title>

    <link rel="stylesheet"
          href="${pageContext.request.contextPath}/css/style.css">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f7fc;
            color: #243047;
        }

        .header {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-align: center;
            padding: 28px 16px;
        }

        .header h1 {
            margin: 0 0 8px;
            font-size: 30px;
        }

        .header p {
            margin: 0;
            font-size: 16px;
        }

        .profile-card {
            width: calc(100% - 32px);
            max-width: 650px;
            margin: 45px auto;
            padding: 32px 40px;
            background: white;
            border-radius: 18px;
            box-shadow: 0 8px 25px rgba(35, 50, 80, 0.09);
        }

        .avatar {
            width: 100px;
            height: 100px;
            margin: 0 auto 24px;
            border-radius: 50%;
            background: #eef2ff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
        }

        .profile-card h2 {
            text-align: center;
            margin: 0 0 35px;
            font-size: 26px;
        }

        .detail {
            padding: 18px 0;
            border-bottom: 1px solid #e8edf5;
            overflow-wrap: anywhere;
        }

        .detail:last-of-type {
            border-bottom: none;
        }

        .label {
            display: block;
            margin-bottom: 8px;
            color: #64748b;
            font-size: 14px;
        }

        .value {
            font-size: 17px;
            font-weight: bold;
            color: #243047;
        }

        .role-badge {
            display: inline-block;
            padding: 7px 14px;
            border-radius: 20px;
            background: #e0f7ef;
            color: #147d57;
            font-size: 13px;
            font-weight: bold;
        }

        .actions {
            display: flex;
            gap: 14px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 14px 12px;
            border-radius: 9px;
            text-align: center;
            text-decoration: none;
            font-weight: bold;
            font-size: 14px;
            transition: 0.2s;
        }

        .back-btn {
            background: #eef2ff;
            color: #4f46e5;
        }

        .back-btn:hover {
            background: #dfe6ff;
        }

        .logout-btn {
            background: #667eea;
            color: white;
        }

        .logout-btn:hover {
            background: #5264d8;
        }

        @media (max-width: 520px) {
            .header {
                padding: 24px 14px;
            }

            .header h1 {
                font-size: 25px;
            }

            .profile-card {
                margin: 25px auto;
                padding: 26px 22px;
            }

            .profile-card h2 {
                font-size: 22px;
            }

            .actions {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>

    <header class="header">
        <h1>&#128100; My Profile</h1>
        <p>Your student account information</p>
    </header>

    <main class="profile-card">

        <div class="avatar">&#127891;</div>

        <h2>Student Information</h2>

        <div class="detail">
            <span class="label">Full Name</span>
            <span class="value"><%= request.getAttribute("studentName") != null
                ? request.getAttribute("studentName") : "Name unavailable" %></span>
        </div>

        <div class="detail">
            <span class="label">Email Address</span>
            <span class="value"><%= request.getAttribute("studentEmail") != null
                ? request.getAttribute("studentEmail") : "Email unavailable" %></span>
        </div>

        <div class="detail">
            <span class="label">Account Role</span>
            <span class="role-badge">STUDENT</span>
        </div>

        <div class="actions">
            <a href="student.html" class="btn back-btn">
                Back to Dashboard
            </a>

            <a href="logout" class="btn logout-btn">
                Logout
            </a>
        </div>

    </main>

</body>
</html>