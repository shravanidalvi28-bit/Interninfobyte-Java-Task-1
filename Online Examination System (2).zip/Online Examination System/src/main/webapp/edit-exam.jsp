<%@ page import="com.onlineexam.model.Exam" %>

<%
    Exam exam = (Exam) request.getAttribute("exam");
%>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <title>Edit Exam</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
        }

        .header {
            background: #667eea;
            color: white;
            padding: 25px;
            text-align: center;
        }

        .container {
            width: 60%;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 8px 0 18px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        button {
            padding: 12px 25px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

    </style>

</head>

<body>

<div class="header">

    <h1>Edit Exam</h1>

</div>

<div class="container">

    <form action="edit-exam" method="post">

        <input
            type="hidden"
            name="id"
            value="<%= exam.getId() %>"
        >

        <label>Exam Title</label>

        <input
            type="text"
            name="title"
            value="<%= exam.getTitle() %>"
            required
        >

        <label>Subject</label>

        <input
            type="text"
            name="subject"
            value="<%= exam.getSubject() %>"
            required
        >

        <label>Duration (minutes)</label>

        <input
            type="number"
            name="duration"
            value="<%= exam.getDuration() %>"
            required
        >

        <label>Total Marks</label>

        <input
            type="number"
            name="totalMarks"
            value="<%= exam.getTotalMarks() %>"
            required
        >

        <button type="submit">
            Update Exam
        </button>

    </form>

</div>

</body>

</html>