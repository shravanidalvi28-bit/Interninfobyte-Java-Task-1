<%@ page import="com.onlineexam.model.Question" %>

<%
    Question question =
            (Question) request.getAttribute("question");
%>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <title>Edit Question</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            margin: 0;
        }

        .header {
            background: #667eea;
            color: white;
            padding: 25px;
            text-align: center;
        }

        .container {
            width: 60%;
            margin: 40px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        label {
            display: block;
            margin-top: 15px;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input,
        textarea,
        select {
            width: 100%;
            padding: 12px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        textarea {
            height: 100px;
            resize: vertical;
        }

        button {
            width: 100%;
            padding: 13px;
            margin-top: 25px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #5568d9;
        }

        .back {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #667eea;
            text-decoration: none;
        }

    </style>

</head>

<body>

    <div class="header">

        <h1>Edit Question</h1>

        <p>Online Examination System</p>

    </div>


    <div class="container">

        <h2>Update Question</h2>

        <form action="edit-question" method="post">

            <!-- Question ID -->

            <input
                type="hidden"
                name="id"
                value="<%= question.getId() %>"
            >


            <!-- Exam ID -->

            <label>Exam ID</label>

            <input
                type="number"
                name="examId"
                value="<%= question.getExamId() %>"
                required
            >


            <!-- Question -->

            <label>Question</label>

            <textarea
                name="questionText"
                required
            ><%= question.getQuestionText() %></textarea>


            <!-- Option A -->

            <label>Option A</label>

            <input
                type="text"
                name="optionA"
                value="<%= question.getOptionA() %>"
                required
            >


            <!-- Option B -->

            <label>Option B</label>

            <input
                type="text"
                name="optionB"
                value="<%= question.getOptionB() %>"
                required
            >


            <!-- Option C -->

            <label>Option C</label>

            <input
                type="text"
                name="optionC"
                value="<%= question.getOptionC() %>"
                required
            >


            <!-- Option D -->

            <label>Option D</label>

            <input
                type="text"
                name="optionD"
                value="<%= question.getOptionD() %>"
                required
            >


            <!-- Correct Answer -->

            <label>Correct Answer</label>

            <select
                name="correctAnswer"
                required
            >

                <option value="">Select Correct Answer</option>

                <option
                    value="A"
                    <%= "A".equals(question.getCorrectAnswer())
                            ? "selected" : "" %>
                >
                    Option A
                </option>

                <option
                    value="B"
                    <%= "B".equals(question.getCorrectAnswer())
                            ? "selected" : "" %>
                >
                    Option B
                </option>

                <option
                    value="C"
                    <%= "C".equals(question.getCorrectAnswer())
                            ? "selected" : "" %>
                >
                    Option C
                </option>

                <option
                    value="D"
                    <%= "D".equals(question.getCorrectAnswer())
                            ? "selected" : "" %>
                >
                    Option D
                </option>

            </select>


            <!-- Marks -->

            <label>Marks</label>

            <input
                type="number"
                name="marks"
                value="<%= question.getMarks() %>"
                min="1"
                required
            >


            <!-- Update -->

            <button type="submit">
                Update Question
            </button>

        </form>


        <a
            class="back"
            href="view-questions"
        >
            ← Back to Questions
        </a>

    </div>

</body>

</html>