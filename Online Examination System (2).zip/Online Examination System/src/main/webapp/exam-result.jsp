
<%
    Integer examId = (Integer) request.getAttribute("examId");
    Integer score = (Integer) request.getAttribute("score");
    Integer totalMarks = (Integer) request.getAttribute("totalMarks");
%>

<!DOCTYPE html>
<html>
<head>
    
<link rel="stylesheet"
      href="${pageContext.request.contextPath}/css/style.css">

    <meta charset="UTF-8">
    <title>Exam Result</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f8;
            text-align: center;
            margin: 0;
        }

        header {
            background: #667eea;
            color: white;
            padding: 25px;
        }

        .result-card {
            background: white;
            width: 60%;
            max-width: 500px;
            margin: 60px auto;
            padding: 35px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .score {
            color: #667eea;
            font-size: 36px;
            font-weight: bold;
        }

        a {
            display: inline-block;
            margin: 10px;
            padding: 12px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Exam Result</h1>
        <p>Online Examination System</p>
    </header>

    <div class="result-card">
        <h2>Exam Submitted Successfully!</h2>

        <p>Your Exam ID: <%= examId %></p>

        <p>Your Score</p>
        <div class="score">
            <%= score %> / <%= totalMarks %>
        </div>

        <a href="view-student-exams">Available Exams</a>
        <a href="student.html">Dashboard</a>
    </div>
</body>
</html>
